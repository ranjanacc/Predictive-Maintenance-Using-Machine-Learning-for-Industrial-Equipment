from django.shortcuts import render
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

def home(request):
    return render(request, 'home.html')
def predict(request):
    return render(request, 'predict.html')
def result(request):
    data = pd.read_csv(r"C:\Users\white\Downloads\Deployment\PdM\ai4i2020.csv")
    data = data.drop(columns=['Product ID', 'UDI', 'Type'])
    data.rename(columns={'Air temperature [K]': 'air_temperature', 'Process temperature [K]': 'process_temperature', 'Rotational speed [rpm]':'rotational_speed', 'Torque [Nm]': 'torque',                            	'Tool wear [min]': 'tool_wear'}, inplace = True)
    data.drop(['TWF', 'HDF', 'PWF', 'OSF', 'RNF'], axis = 1, inplace = True)
    X= data.drop("Machine failure",axis=1) 
    Y= data["Machine failure"]

    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

    model = LogisticRegression()
    model.fit(X_train, Y_train)

    val1 = float(request.GET['n1'])
    val2 = float(request.GET['n2'])
    val3 = float(request.GET['n3'])
    val4 = float(request.GET['n4'])
    val5 = float(request.GET['n5'])


    pred = model.predict([[val1, val2, val3, val4, val5]])

    result1= ""
    if pred==[1]:
        result1="Machine is about to fail! Take pre-emptive care now."
    else:
        result1="Machine in optimal condition!"



    return render(request, "predict.html", {"result2":result1})

   